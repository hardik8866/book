//
//  AuthorTableViewController.h
//  
//
//  Created by Royal on 12/4/18.
//

#import <UIKit/UIKit.h>

@interface AuthorTableViewController : UITableViewController

@end
