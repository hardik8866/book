//
//  ReadPdfViewController.h
//  book2
//
//  Created by MyClassCampus on 4/10/18.
//  Copyright © 2018 Royal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ReadPdfViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIWebView *webview;
@property (weak, nonatomic) IBOutlet UILabel *lblpdfname;
@property (weak,nonatomic) NSString *Pdfurl;
@property (weak,nonatomic) NSString *PdfName;
@end
