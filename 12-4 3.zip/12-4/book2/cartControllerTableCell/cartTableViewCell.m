//
//  cartTableViewCell.m
//  book2
//
//  Created by Royal on 2/3/18.
//  Copyright © 2018 Royal. All rights reserved.
//

#import "cartTableViewCell.h"

@implementation cartTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
