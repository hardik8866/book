//
//  SearchDetailViewController.h
//  book2
//
//  Created by Royal on 24/2/18.
//  Copyright © 2018 Royal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchDetailViewController : UIViewController
@property (weak, nonatomic)NSURL *imgUrl;
@property (weak, nonatomic)NSString *isbn;
@property (weak, nonatomic)NSString *name;
@property (weak, nonatomic)NSString *price;
@property (weak, nonatomic)NSString *author;
@property (weak, nonatomic)NSString *information;
@end
