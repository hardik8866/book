//
//  secondViewController.m
//  book2
//
//  Created by Royal on 13/2/18.
//  Copyright © 2018 Royal. All rights reserved.
//

#import "secondViewController.h"
#import "RKSwipeBetweenViewControllers.h"
#import "ViewController.h"
#import "signUpViewController.h"
#import "EventViewController.h"
#import "GallaryViewController.h"
#import "HomeViewController.h"


@interface secondViewController ()


@end

@implementation secondViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    
    
//    UIView *view =[[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 50)];
//    view.backgroundColor = [UIColor redColor];
//    [self.view addSubview:view];
    
    

    self.window = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    UIPageViewController *pageController = [[UIPageViewController alloc] initWithTransitionStyle:UIPageViewControllerTransitionStyleScroll navigationOrientation:UIPageViewControllerNavigationOrientationHorizontal options:nil];
    
    
    
    RKSwipeBetweenViewControllers *navigationController = [[RKSwipeBetweenViewControllers alloc]initWithRootViewController:pageController];
    
    
    UIStoryboard *Storyborrd = [UIStoryboard storyboardWithName:@"Main" bundle: nil];
    
//    UIViewController *demo = [[UIViewController alloc]init];
//    secondViewController *demo = [[secondViewController alloc]init];
//    UIViewController *demo = [Storyborrd instantiateViewControllerWithIdentifier:@"secondViewController"];
//    EventViewController *demo2 = [[EventViewController alloc]init];
    UIViewController *demo = [Storyborrd instantiateViewControllerWithIdentifier:@"HomeViewController"];
    UIViewController *demo2 = [Storyborrd instantiateViewControllerWithIdentifier:@"EventViewController"];
    UIViewController *demo3 = [Storyborrd instantiateViewControllerWithIdentifier:@"AuthViewController"];
     UIViewController *demo4 = [Storyborrd instantiateViewControllerWithIdentifier:@"QandAViewController"];
    UIViewController *demo5 = [Storyborrd instantiateViewControllerWithIdentifier:@"ProfileViewController"];
    //    UIViewController *demo4 = [[UIViewController alloc]init];
    //    demo.view.backgroundColor = [UIColor redColor];
    //    demo2.view.backgroundColor = [UIColor whiteColor];
    //    demo3.view.backgroundColor = [UIColor grayColor];
    //    demo4.view.backgroundColor = [UIColor orangeColor];
    [navigationController.viewControllerArray addObjectsFromArray:@[demo,demo2,demo3,demo4,demo5]];
    
    self.window.rootViewController = navigationController;
    [self.window makeKeyAndVisible];
}

// Navigation Items

- (IBAction)btnSlideoutmenu:(id)sender {
    
    
}

- (IBAction)btnsearchbar:(id)sender {
    
    //    _searchbar.isHidden = true
    
}





//- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
//{
//    return 15;
//}
//- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
//{
//    UICollectionViewCell *cell=[collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
//    
//    UILabel *testlbl = [[UILabel alloc]init];
//    testlbl = [cell viewWithTag:1];
//    testlbl.text = @"1";
//    return cell;
//    
//}

//-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
//{
//    UIViewController *bookview = [self.storyboard instantiateViewControllerWithIdentifier:@"bookdetailView"];
//    [self.navigationController pushViewController:bookview animated:true];
//
//
//}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}







@end
