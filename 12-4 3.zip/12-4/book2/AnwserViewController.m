//
//  AnwserViewController.m
//  book2
//
//  Created by Royal on 12/4/18.
//  Copyright © 2018 Royal. All rights reserved.
//

#import "AnwserViewController.h"

@interface AnwserViewController ()

@end

@implementation AnwserViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    _lblQustion.text = self.qustion;
    _lblAnwser.text = self.Anwser;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)btnback:(id)sender {
   [self dismissModalViewControllerAnimated:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
