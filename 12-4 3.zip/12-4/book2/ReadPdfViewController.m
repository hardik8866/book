//
//  ReadPdfViewController.m
//  book2
//
//  Created by MyClassCampus on 4/10/18.
//  Copyright © 2018 Royal. All rights reserved.
//

#import "ReadPdfViewController.h"

@interface ReadPdfViewController ()<UIWebViewDelegate>
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *loder;

@end

@implementation ReadPdfViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"%@", _Pdfurl);
    // Do any additional setup after loading the view.
    self.lblpdfname.text=_PdfName;
    NSURL *targetURL = [NSURL URLWithString:[NSString stringWithFormat:@"%@",_Pdfurl]];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:targetURL];
    [self.webview loadRequest:request];
    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:20 target:self selector:@selector(timerCalled) userInfo:nil repeats:NO];
    
    [_loder startAnimating];
}
- (IBAction)back:(id)sender {
    [self dismissModalViewControllerAnimated:YES];
}
-(void)timerCalled
{
    _loder.hidden = YES;
    [_loder stopAnimating];
    NSLog(@"Timer Called");
    // Your Code
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    NSLog(@"Current URL = %@",webView.request.URL);
    
    //-- Add further custom actions if needed
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
