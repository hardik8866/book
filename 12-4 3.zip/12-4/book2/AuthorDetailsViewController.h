//
//  AuthorDetailsViewController.h
//  book2
//
//  Created by Royal on 12/4/18.
//  Copyright © 2018 Royal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AuthorDetailsViewController : UIViewController
@property (weak,nonatomic) NSString *name;
@property (weak,nonatomic) NSString *email;
@property (weak,nonatomic) NSString *Information;
@property (weak, nonatomic) IBOutlet UILabel *auth_name;
@property (weak, nonatomic) IBOutlet UILabel *auth_email;
@property (weak, nonatomic) IBOutlet UILabel *auth_information;

 @end
