//
//  AuthorDetailsViewController.m
//  book2
//
//  Created by Royal on 12/4/18.
//  Copyright © 2018 Royal. All rights reserved.
//

#import "AuthorDetailsViewController.h"

@interface AuthorDetailsViewController ()
{
    
}
@end

@implementation AuthorDetailsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    _auth_name.text = self.name;
    _auth_email.text = self.email;
    _auth_information.text = self.Information;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)btnback:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
