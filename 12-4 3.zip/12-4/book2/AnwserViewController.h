//
//  AnwserViewController.h
//  book2
//
//  Created by Royal on 12/4/18.
//  Copyright © 2018 Royal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AnwserViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *lblQustion;
@property (weak, nonatomic) IBOutlet UILabel *lblAnwser;
@property (weak, nonatomic) NSString *qustion;
@property (weak, nonatomic) NSString *Anwser;

@end
