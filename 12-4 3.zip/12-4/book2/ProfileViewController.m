//
//  ProfileViewController.m
//  book2
//
//  Created by Royal on 26/2/18.
//  Copyright © 2018 Royal. All rights reserved.
//

#import "ProfileViewController.h"
#import "ViewController.h"
@interface ProfileViewController ()
@property (weak, nonatomic) IBOutlet UILabel *lblname;
@property (weak, nonatomic) IBOutlet UILabel *lblemail;
@property (weak, nonatomic) IBOutlet UILabel *mobile;

@end

@implementation ProfileViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    _lblname.text = [[NSUserDefaults standardUserDefaults]
                            stringForKey:@"Name"];
    _lblemail.text = [[NSUserDefaults standardUserDefaults]
                      stringForKey:@"Email"];
    _mobile.text = [[NSUserDefaults standardUserDefaults]
                    stringForKey:@"Phone_no"];
    
 
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)back:(id)sender {
    [self dismissViewControllerAnimated:true completion:nil];
}
- (IBAction)BtnLogout:(id)sender {
    NSString *tempString = @"logout";
    [NSUserDefaults.standardUserDefaults setObject:tempString forKey:@"login"];
    ViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"ViewController"];
  //  [self.navigationController pushViewController:vc animated:true];
    [self presentViewController:vc animated:YES completion:nil];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
