//
//  QandAViewController.m
//  book2
//
//  Created by Royal on 26/2/18.
//  Copyright © 2018 Royal. All rights reserved.
//

#import "QandAViewController.h"
#import "AnwserViewController.h"
@interface QandAViewController () <UITableViewDataSource,UITableViewDelegate,WebServicesDelegate>
{
    NSArray *message;
    NSArray *qid;
    NSMutableArray *qustion;
      NSMutableArray *Anwser;
}
@end

@implementation QandAViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    qustion = [[NSMutableArray alloc]init];
    Anwser = [[NSMutableArray alloc]init];
    [qustion addObject:@"1.What is the first book that made you cry?"];
    [qustion addObject:@"2.How long does it take you to write a book?"];
    [qustion addObject:@"3.What is your work schedule like when you're writing?"];
    [qustion addObject:@"4.How do books get published?"];
    [qustion addObject:@"5.Where do you get your information or ideas for your books?"];
    [qustion addObject:@"6.How many books have you written? Which is your favourite?"];
    [Anwser addObject:@"I can remember sitting in class during silent reading time and trying to stifle sobs as I ugly-cried in my seat. The characters were very real for me, and I hung on every word in the book. I recall telling myself that surely the author (S.E. Hinton) wouldn't allow Johnny to die. I truly grieved his loss! I think it was the first book that shook me. —Jody E. F."];
    [Anwser addObject:@"It can take a long time to write a novel, if you're doing research or you get stuck, or if you're fine-tuning sentences or having trouble with point of view. On the other hand, other writers, like author Jane Green, whose newest novel, Tempting Fate, is a NYT best-seller, writes her books in six months"];
    [Anwser addObject:@"An Author produces original written copy for any number of different media including books, magazines, newspaper articles, screen plays and websites. They may write on a number of subjects spanning both fiction and non-fiction. A natural human love of story telling, the innate desire to be entertained, to learn from others' mistakes or successes, to better understand the world we live in, the other people we share it with and ultimately ourselves - all of this is transmitted to us through literature. It is an author's job to paint the fantastical, give meaning to the mundane and reveal the messages hidden in our everyday lives."];
     [Anwser addObject:@"If you want to get your book published by a traditional route (like Ian McEwan's Atonement, right), then: you need to get your work accepted by a literary agent, because the big publishers only take submissions from literary agents. ... the publisher will invest in editorial, copyediting, and design work."];
     [Anwser addObject:@"Lists & outlines. After sketching out the “big picture” of your book, the next step can be to expand your sketch listing the main idea and key supporting points for each chapter. There’s something satisfying about writing with a narrow felt-tip marker on a fresh page, fleshing out each topic with information and ideas I want to share"];
    [Anwser addObject:@"I've read the entire of Christopher Paolini's Inheritance Cycle upwards of 10 times.Those books are massive. There are four books, about 700 pages each. They're pretty detailed, so on each read-through I've picked up new snippets of information and bits of foreshadowing that I'd missed before."];
    WebServices *objweb;
    objweb = [WebServices sharedInstance];
    objweb.delegate = self;
    [objweb callApiWithParameters:nil apiName:@"http://someshwarmahadev.com/royaltech/index.php/api/list_question_answer" type:GET_REQUEST loader:NO view:self];

    // Do any additional setup after loading the view.
}
-(void)response:(NSDictionary *)responseDict apiName:(NSString *)apiName ifAnyError:(NSError *)error{
    printf("%@", responseDict);
    NSError *jsonError;
    NSDictionary *dic;
    dic = [NSJSONSerialization JSONObjectWithData:responseDict
                                          options:NSJSONReadingMutableContainers
                                            error:&jsonError];
    message = [dic valueForKey:@"message"];
    qid = [dic valueForKeyPath:@"message.question"];
    printf("%s", qid);
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return qustion.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    UILabel *lbl=(UILabel *)[cell viewWithTag:10];
    lbl.text = qustion[indexPath.row];
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    AnwserViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"AnwserViewController"];
    vc.qustion = qustion[indexPath.row];
    vc.Anwser = Anwser[indexPath.row];
    [self presentViewController:vc animated:YES completion:nil];
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

@end
