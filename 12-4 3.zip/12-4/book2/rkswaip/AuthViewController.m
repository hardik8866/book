//
//  AuthViewController.m
//  book2
//
//  Created by Royal on 12/4/18.
//  Copyright © 2018 Royal. All rights reserved.
//

#import "AuthViewController.h"
#import "AuthorDetailsViewController.h"
#define GET_REQUEST                             @"GET"
@interface AuthViewController ()<UITableViewDataSource,UITableViewDelegate,WebServicesDelegate>
{
    NSArray *name;
    NSArray *email;
    NSArray *information;
}
@end

@implementation AuthViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    WebServices *objweb;
    objweb = [WebServices sharedInstance];
    objweb.delegate = self;
    
    [objweb callApiWithParameters:nil apiName:@"http://someshwarmahadev.com/royaltech/index.php/api/author_list/" type:GET_REQUEST loader:NO view:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return name.count;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    UILabel *lblname = (UILabel *)[cell viewWithTag:10];
    lblname.text = [NSString stringWithFormat:@"%@", name[indexPath.row]];
    UILabel *lblemail = (UILabel *)[cell viewWithTag:20];
    lblemail.text = [NSString stringWithFormat:@"%@",email[indexPath.row]];
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    UIStoryboard *sb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    AuthorDetailsViewController *vc = [sb instantiateViewControllerWithIdentifier:@"AuthorDetailsViewController"];
    vc.name = [NSString stringWithFormat:@"%@", name[indexPath.row]];
    vc.email = [NSString stringWithFormat:@"%@",email[indexPath.row]];
    vc.Information = [NSString stringWithFormat:@"%@",information[indexPath.row]];
[self presentViewController:vc animated:YES completion:NULL];
}
-(void)response:(NSDictionary *)responseDict apiName:(NSString *)apiName ifAnyError:(NSError *)error{
    printf("%@", responseDict);
    NSError *jsonError;
    //    NSDictionary *dic;
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseDict
                                          options:NSJSONReadingMutableContainers
                                            error:&jsonError];
    name = [dic valueForKeyPath:@"message.name"];
    email = [dic valueForKeyPath:@"message.email_id"];
    information = [dic valueForKeyPath:@"message.information"];
    
    [self.tblview reloadData];
}
@end
