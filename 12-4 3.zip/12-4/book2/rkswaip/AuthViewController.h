//
//  AuthViewController.h
//  book2
//
//  Created by Royal on 12/4/18.
//  Copyright © 2018 Royal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AuthViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITableView *tblview;

@end
