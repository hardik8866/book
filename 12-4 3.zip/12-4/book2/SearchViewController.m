//
//  SearchViewController.m
//  book2
//
//  Created by Royal on 24/2/18.
//  Copyright © 2018 Royal. All rights reserved.
//

#import "SearchViewController.h"
#import "SearchDetailViewController.h"

@interface SearchViewController ()<UITextFieldDelegate, UITableViewDelegate, UITableViewDataSource>
{
    NSArray *name;
    NSArray *isbn;
    NSArray *price;
    NSArray *bookauthor;
    NSArray *bookimageurl;
    NSArray *bookCategory;
    NSArray *information;
    NSString *tempString;
    
    NSMutableArray *shortedArray;
}
@property (weak, nonatomic) IBOutlet UITextField *txtSearch;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@end

@implementation SearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    shortedArray = [[NSMutableArray alloc]init];
    tempString = [[NSString alloc]init];
    _txtSearch.delegate = self;
    
    name = [_tempDict valueForKeyPath:@"message.name"];
    isbn = [_tempDict valueForKeyPath:@"message.isbn"];
    price = [_tempDict valueForKeyPath:@"message.price"];
    bookauthor = [_tempDict valueForKeyPath:@"message.book_author"];
    bookimageurl = [_tempDict valueForKeyPath:@"message.book_image"];
    bookCategory = [_tempDict valueForKeyPath:@"message.category"];
    information = [_tempDict valueForKeyPath:@"message.information"];
    
    
    // Do any additional setup after loading the view.
}
- (IBAction)backAction:(id)sender {
    [self dismissViewControllerAnimated:true completion:nil];
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    tempString = [tempString stringByAppendingString:string];
    for (int i = 0; i<bookauthor.count; i++) {
        NSString *extra;
        extra = bookauthor[i];
        NSRange stringLocation = [extra rangeOfString:tempString];
        if (stringLocation.location == NSNotFound){
            
        }else{
            [shortedArray addObject:extra];
        }
    }
    [_tableView reloadData];
    return true;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return shortedArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    
    UIImageView *imageView = [cell viewWithTag:1];
    UILabel *lblisbn = [cell viewWithTag:2];
    UILabel *lblName = [cell viewWithTag:3];
    UILabel *lblPrice = [cell viewWithTag:4];
    UILabel *lblAuthor = [cell viewWithTag:5];
    
    [imageView sd_setImageWithURL:[bookimageurl objectAtIndex:indexPath.row] placeholderImage:[UIImage imageNamed:@"loding.jpg"]];
    
    lblisbn.text = [isbn objectAtIndex:indexPath.row];
    lblName.text = [name objectAtIndex:indexPath.row];
    lblPrice.text = [price objectAtIndex:indexPath.row];
    lblAuthor.text =[bookauthor objectAtIndex:indexPath.row];
    
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    UIStoryboard *sb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    SearchDetailViewController *vc = [sb instantiateViewControllerWithIdentifier:@"SearchDetailViewController"];
    vc.imgUrl = bookimageurl[indexPath.row];
    vc.isbn = isbn[indexPath.row];
    vc.name = name[indexPath.row];
    vc.price = price[indexPath.row];
    vc.author = bookauthor[indexPath.row];
    [self presentViewController:vc animated:true completion:nil];
}
- (CGFloat)tableView:(UITableView *)tableView
heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 151;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
