//
//  AppDelegate.h
//  book2
//
//  Created by Royal on 13/2/18.
//  Copyright © 2018 Royal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (retain, nonatomic) NSString *Name;
@property (retain, nonatomic) NSString *Phone_no;
@property (retain, nonatomic) NSString *Email;

@end

