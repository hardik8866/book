//
//  signUpViewController.m
//  book2
//
//  Created by Royal on 13/2/18.
//  Copyright © 2018 Royal. All rights reserved.
//

#import "signUpViewController.h"
#import "ViewController.h"
#import "secondViewController.h"
#import <Foundation/Foundation.h>
#import "WebServices.h"

#define POST_REQUEST                            @"POST"

@interface signUpViewController ()  <WebServicesDelegate>

@end

@implementation signUpViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)btnActionAllRadyHaveAnAccount:(id)sender {
    [self.navigationController popViewControllerAnimated:true];
}
- (IBAction)btnActionSigingUp:(id)sender {
    if ([_txtEmail.text isEqualToString:@""] || [_txtpasspwrd.text isEqualToString:@""] || [_txtPhoneNumber.text isEqualToString:@""]){
        
    }else{
        bool emailIsValid = [self validateEmailWithString:_txtEmail.text];
        if (emailIsValid){
            if ([_txtPhoneNumber.text isEqualToString:@""] || [_txtpasspwrd.text isEqualToString:@""]){
                UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Error" message:@"pls Enter Valid Details" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
                [alert show];
            }else{
                if (_txtPhoneNumber.text.length == 10){
                    if (_txtpasspwrd.text.length <= 8){
                        printf("enter valid atlist 8 digits");
                        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Error" message:@"pls Enter Valid Details" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
                        [alert show];
                    }else{
                        if ([_txtConformPassword.text isEqualToString:@""]){
                            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Error" message:@"pls Enter Valid Details" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
                            [alert show];
                        }else{
                            if ([_txtConformPassword.text isEqualToString:_txtpasspwrd.text]){
                                [self Signapicall];
                            }else{
                                UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Error" message:@"pls Enter Valid Details" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
                                [alert show];
                            }
                        }
                        
                    }
                }else{
                    printf("eneter Valid number");
                    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Error" message:@"pls Enter Valid Details" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
                    [alert show];
                }
            }
        }else{
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Error" message:@"pls Enter Valid Details" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [alert show];
        }
    }
}
- (BOOL)validateEmailWithString:(NSString*)email
{
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:email];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
-(void)Signapicall
{
    WebServices *objweb;
    objweb = [WebServices sharedInstance];
    objweb.delegate = self;
    NSDictionary *dic = @{
                          @"name":_txtName.text,
                          @"email_id":_txtEmail.text,
                          @"phone_no":_txtPhoneNumber.text,
                          @"pass_wd":_txtpasspwrd.text
                          };
    [objweb callApiWithParameters:dic apiName:@"http://someshwarmahadev.com/royaltech/index.php/api/sign_up" type:POST_REQUEST loader:NO view:self];
    
}
///////// Response /////////
-(void)response:(NSDictionary *)responseDict apiName:(NSString *)apiName ifAnyError:(NSError *)error{
//    printf("%s", responseDict);
     int status = [responseDict valueForKey:@"status"];
    NSString *str = [responseDict valueForKey:@"message"];
    if (status == 19){
        printf("done");
        UIViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"secondViewController"];
        [self.navigationController pushViewController:vc animated:true];
    }else{
        
    }
    
}



@end
