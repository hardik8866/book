//
//  ViewController.m
//  book2
//
//  Created by Royal on 13/2/18.
//  Copyright © 2018 Royal. All rights reserved.
//

#import "ViewController.h"
#import "secondViewController.h"
#import "signUpViewController.h"


NSString *UserId;



@interface ViewController () <WebServicesDelegate>
{
    NSString *tempString;
}
@property (weak, nonatomic) IBOutlet UITextField *txtUserName;
@property (weak, nonatomic) IBOutlet UITextField *txtPassowrd;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSString *savedValue = [[NSUserDefaults standardUserDefaults]
                            stringForKey:@"login"];
    if ([savedValue  isEqual: @"true"])
    {
       
        secondViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"secondViewController"];
        [self.navigationController pushViewController:vc animated:true];
    }
    else
    {
        NSLog(@"Not Login");
        
    }
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    NSLog(@"Current URL = %@",webView.request.URL);
    
    //-- Add further custom actions if needed 
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)signUpAction:(id)sender {
    
    UIViewController *homeVC = [self.storyboard instantiateViewControllerWithIdentifier:@"signUpViewController"];
    [self.navigationController pushViewController:homeVC animated:true];
}
- (IBAction)loginAction:(id)sender {

    
//    UIViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"secondViewController"];
//    [self.navigationController pushViewController:vc animated:true];

    
    
//    UIViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"secondViewController"];
    bool EmailIsValid = [self validateEmailWithString:_txtUserName.text];
    if (EmailIsValid){
        if ([_txtPassowrd.text  isEqual: @""] || _txtPassowrd.text.length <= 8 ) {
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Error" message:@"Pls Enter Valid Details" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [alert show];
        }else{
            printf("email IsValid");
//            UIViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"secondViewController"];
//            [self.navigationController pushViewController:vc animated:true];
            [self callAP];
//            [self.navigationController pushViewController:vc animated:true];
        }
    }else{
        printf("email is in valid");
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Error" message:@"Pls Enter Valid Details" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
    }
    
//    [self.navigationController pushViewController:vc animated:true];
    
    
    
}
-(void)callAP{
    WebServices *objweb;
    objweb = [WebServices sharedInstance];
    objweb.delegate = self;
    NSDictionary *dic = @{
                          @"email_id":_txtUserName.text,
                          @"pass_wd":_txtPassowrd.text
                          };
    [objweb callApiWithParameters:dic apiName:@"http://someshwarmahadev.com/royaltech/index.php/api/login" type:POST_REQUEST loader:NO view:self];
}
-(void)response:(NSDictionary *)responseDict apiName:(NSString *)apiName ifAnyError:(NSError *)error{
    int status = [responseDict valueForKey:@"status"];
    
    if (status == 19){
        AppDelegate *a = DELEGATE;
        UserId = [responseDict valueForKeyPath:@"message.id"];
        a.Email = [NSString stringWithFormat:@"%@",[responseDict valueForKeyPath:@"message.email_id"]];
        a.Name = [NSString stringWithFormat:@"%@",[responseDict valueForKeyPath:@"message.name"]];
        a.Phone_no =[NSString stringWithFormat:@"%@",[responseDict valueForKeyPath:@"message.phone_no"]];
        
        printf("%@",UserId);
        tempString = @"true";
        [NSUserDefaults.standardUserDefaults setObject:tempString forKey:@"login"];
        secondViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"secondViewController"];
        [self dismissModalViewControllerAnimated:YES];
        [self.navigationController pushViewController:vc animated:true];
    }else{
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Error" message:@"First You need to registration" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
    }
    
}
- (BOOL)validateEmailWithString:(NSString*)email
{
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:email];
}

@end
