//
//  bookdetailView.h
//  book2
//
//  Created by Royal on 13/2/18.
//  Copyright © 2018 Royal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface bookdetailView : UIViewController

@property (weak, nonatomic) IBOutlet UIImageView *objimgview;
@property (weak, nonatomic) IBOutlet UILabel *objisbn;

@property (weak, nonatomic) IBOutlet UILabel *objName;

@property (weak, nonatomic) IBOutlet UILabel *objPrice;
@property (weak, nonatomic) IBOutlet UILabel *objAuthor;
@property (weak, nonatomic) IBOutlet UITextView *objinformationTextview;

@property (nonatomic, retain) NSURL *passimgURL;
@property (nonatomic, retain) NSString *passisbn;
@property (nonatomic, retain) NSString *passname;
@property (nonatomic, retain) NSString *passprice;
@property (nonatomic, retain) NSString *passauthor;
@property (nonatomic, retain) NSString *passinformation;
@property (nonatomic, retain) NSString *BookUrl;
@property (weak, nonatomic) IBOutlet UIButton *btnAddToCart;


@end
