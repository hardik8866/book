//
//  cartTableViewCell.h
//  book2
//
//  Created by Royal on 2/3/18.
//  Copyright © 2018 Royal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface cartTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *lblIsbnNumber;
@property (weak, nonatomic) IBOutlet UILabel *lblQuentity;
@property (weak, nonatomic) IBOutlet UILabel *lblDate;
@property (weak, nonatomic) IBOutlet UILabel *lblBookTotal;
@property (weak, nonatomic) IBOutlet UILabel *lblPrice;

@end
