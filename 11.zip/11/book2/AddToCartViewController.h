//
//  AddToCartViewController.h
//  book2
//
//  Created by Royal on 26/2/18.
//  Copyright © 2018 Royal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddToCartViewController : UIViewController <UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UIButton *btnBack;
@property (nonatomic, weak) NSURL *imageUrl;
@property (nonatomic, weak) NSString * price;
@property (nonatomic, weak) NSString * isbnNumber;
@property (nonatomic, weak) NSString * bookName;

@end
