//
//  signUpViewController.h
//  book2
//
//  Created by Royal on 13/2/18.
//  Copyright © 2018 Royal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface signUpViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *txtEmail;
@property (weak, nonatomic) IBOutlet UITextField *txtPhoneNumber;
@property (weak, nonatomic) IBOutlet UITextField *txtpasspwrd;
@property (weak, nonatomic) IBOutlet UITextField *txtConformPassword;
@property (weak, nonatomic) IBOutlet UIButton *btnAllreadyHaveAccount;
@property (weak, nonatomic) IBOutlet UIButton *btnSignUp;
@property (weak, nonatomic) IBOutlet UITextField *txtName;

@end
