//
//  EventDetailViewController.h
//  book2
//
//  Created by Royal on 13/2/18.
//  Copyright © 2018 Royal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EventDetailViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIImageView *objimgview;
@property (weak, nonatomic) IBOutlet UILabel *objName;
@property (weak, nonatomic) IBOutlet UILabel *objOrganizeName;
@property (weak, nonatomic) IBOutlet UILabel *objLocation;

@property (nonatomic, retain) NSURL *imgURL;
@property (nonatomic, retain) NSString *passName;
@property (nonatomic, retain) NSString *passOrganize;
@property (nonatomic, retain) NSString *passLocation;
@property (nonatomic, weak) NSString *longitude;
@property (nonatomic, weak) NSString *letitude;

@property (nonatomic, weak) NSString * title;
@property (nonatomic, weak) NSString * subTitle;



@end
