//
//  cartListViewController.m
//  book2
//
//  Created by Royal on 27/2/18.
//  Copyright © 2018 Royal. All rights reserved.
//

#import "cartListViewController.h"
#import "ViewController.h"
#import "cartTableViewCell.h"

@interface cartListViewController () <UITableViewDelegate, UITableViewDataSource, WebServicesDelegate>{
    ViewController *viewController;
    NSMutableArray *isbnNumber;
    NSMutableArray *bookQuentity;
    NSMutableArray *bookPrice;
    NSMutableArray *bookTotalAmount;
    NSMutableArray *bookAddDate;
}
@property (weak, nonatomic) IBOutlet UIButton *btnBack;
@property (weak, nonatomic) IBOutlet UITableView *objtableView;

@end

@implementation cartListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self callAPI];
    isbnNumber = [[NSMutableArray alloc]init];
    bookQuentity = [[NSMutableArray alloc]init];
    bookPrice = [[NSMutableArray alloc]init];
    bookTotalAmount = [[NSMutableArray alloc]init];
    bookAddDate = [[NSMutableArray alloc]init];
}
-(void)callAPI{
    WebServices *objweb;
    objweb = [WebServices sharedInstance];
    objweb.delegate = self;
    NSDictionary *dic = @{
                          @"user_id":UserId
                          };
    [objweb callApiWithParameters:dic apiName:@"http://someshwarmahadev.com/royaltech/index.php/api/addtocart_list" type:POST_REQUEST loader:NO view:self];
}
-(void)response:(NSDictionary *)responseDict apiName:(NSString *)apiName ifAnyError:(NSError *)error{
    printf("%s", responseDict);
    
    NSArray *temp = [responseDict valueForKey:@"message"];
    _lblTotalAmountOfUserBook.text = [temp valueForKey:@"final_total"];
    NSArray *data = [temp valueForKey:@"data"];
    for (int i = 0;i<data.count;i++){
        NSDictionary *data1 = data[i];
        [isbnNumber addObject:[data1 valueForKey:@"id"]];
        [bookQuentity addObject:[data1 valueForKey:@"book_qty"]];
        [bookPrice addObject:[data1 valueForKey:@"price"]];
        [bookTotalAmount addObject:[data1 valueForKey:@"total_amount"]];
        [bookAddDate addObject:[data1 valueForKey:@"created_at"]];
    }
    [_objtableView reloadData];

    
}
- (IBAction)backAction:(id)sender {
    [self dismissViewControllerAnimated:true completion:nil];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return isbnNumber.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
     cartTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    cell.lblIsbnNumber.text = isbnNumber[indexPath.row];
    cell.lblQuentity.text = bookQuentity[indexPath.row];
    cell.lblDate.text = bookAddDate[indexPath.row];
    cell.lblPrice.text = bookPrice[indexPath.row];
    cell.lblBookTotal.text = [NSString stringWithFormat:@"%@",bookTotalAmount[indexPath.row]];
    return cell;
}
@end
