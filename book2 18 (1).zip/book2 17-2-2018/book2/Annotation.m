//
//  Annotation.m
//  book2
//
//  Created by Royal on 26/2/18.
//  Copyright © 2018 Royal. All rights reserved.
//

#import "Annotation.h"

@implementation Annotation
@synthesize coordinate,title,subTitle;

@end
