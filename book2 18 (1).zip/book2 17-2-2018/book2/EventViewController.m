//
//  EventViewController.m
//  book2
//
//  Created by Royal on 13/2/18.
//  Copyright © 2018 Royal. All rights reserved.
//

#import "EventViewController.h"
#import "EventDetailViewController.h"
#import "WebServices.h"
#define GET_REQUEST                             @"GET"

@interface EventViewController () <WebServicesDelegate,UITableViewDelegate,UITableViewDataSource>
{
    NSArray *message;
    NSArray *name;
    NSArray *location;
    NSArray *organaizer_name;
    NSArray *imageurl;
    NSArray *letitude;
    NSArray *longitude;
    
}
@end
@implementation EventViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    WebServices *objweb;
    objweb = [WebServices sharedInstance];
    objweb.delegate = self;
    [objweb callApiWithParameters:nil apiName:@"http://someshwarmahadev.com/royaltech/index.php/api/event_list" type:GET_REQUEST loader:NO view:self];
    // Do any additional setup after loading the view.
}

-(void)response:(NSDictionary *)responseDict apiName:(NSString *)apiName ifAnyError:(NSError *)error{
    printf("%@", responseDict);
    NSError *jsonError;
    NSDictionary *dic;
    dic = [NSJSONSerialization JSONObjectWithData:responseDict
                                                   options:NSJSONReadingMutableContainers
                                                     error:&jsonError];
//    printf("%@",dic);
   
    message = [dic valueForKey:@"message"];
    
    name = [dic valueForKeyPath:@"message.name"];
    imageurl = [dic valueForKeyPath:@"message.image"];
    location = [dic valueForKeyPath:@"message.location"];
    organaizer_name = [dic valueForKeyPath:@"message.orgranazer_name"];
    letitude = [dic valueForKeyPath:@"message.letitude"];
    longitude = [dic valueForKey:@"message.longitude"];
    [self.TblEventView reloadData];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return name.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    UIImageView *imageView = [cell viewWithTag:1];
    UILabel *lbltag2 = [cell viewWithTag:2];
    UILabel *lbltag3 = [cell viewWithTag:3];
    UILabel *lbltag4 = [cell viewWithTag:4];
    
    [imageView sd_setImageWithURL:[imageurl objectAtIndex:indexPath.row] placeholderImage:[UIImage imageNamed:@"loding.jpg"]];
    
    lbltag2.text = [name objectAtIndex:indexPath.row];
    lbltag3.text = [organaizer_name objectAtIndex:indexPath.row];
    lbltag4.text = [location objectAtIndex:indexPath.row];
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
    UIStoryboard *sb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    EventDetailViewController *vc = [sb instantiateViewControllerWithIdentifier:@"EventDetailViewController"];

    vc.imgURL = imageurl[indexPath.row];
    vc.passName = name[indexPath.row];
    vc.passOrganize = organaizer_name[indexPath.row];
    vc.passLocation = location[indexPath.row];
    vc.letitude = letitude[indexPath.row];
    vc.longitude = longitude[indexPath.row];
    
    [self presentViewController:vc animated:YES completion:NULL];
    
    
   // EventDetailViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"EventDetailViewController"];
    
    
   
   // [self.navigationController presentViewController:vc animated:true completion:nil];
}


@end
