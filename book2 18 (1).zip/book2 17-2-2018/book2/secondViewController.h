//
//  secondViewController.h
//  book2
//
//  Created by Royal on 13/2/18.
//  Copyright © 2018 Royal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface secondViewController : UIViewController
@property (strong, nonatomic) UIWindow *window;

@property (weak, nonatomic) IBOutlet UIButton *objbtnslidemenu;
@property (weak, nonatomic) IBOutlet UIButton *objbtnsearchbar;
@property (weak, nonatomic) IBOutlet UISearchBar *searchbar;



@end
