//
//  SearchViewController.h
//  book2
//
//  Created by Royal on 24/2/18.
//  Copyright © 2018 Royal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchViewController : UIViewController
@property (weak, nonatomic)NSDictionary * tempDict;

@end
