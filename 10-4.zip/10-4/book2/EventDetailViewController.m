//
//  EventDetailViewController.m
//  book2
//
//  Created by Royal on 13/2/18.
//  Copyright © 2018 Royal. All rights reserved.
//

#import "EventDetailViewController.h"
#import "EventViewController.h"
#import <MapKit/MapKit.h>
#import "Annotation.h"

#define leti 23.0802540;
#define longi 72.5719300;


@interface EventDetailViewController ()
@property (weak, nonatomic) IBOutlet MKMapView *objMapView;

@end


@implementation EventDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    //Map
    
    MKCoordinateRegion region;
    
    CLLocationCoordinate2D cordinate;
    NSLog(@"letitude  %@ : " , self.letitude);
    float temp = [self.letitude floatValue];
    float temp2 = [self.longitude floatValue];
    NSLog(@"temp : %f : " , temp);
     NSLog(@"temp : %f : " , temp2);
    cordinate.latitude = temp;
    cordinate.longitude = temp2;
    
    MKCoordinateSpan span;
    span.latitudeDelta = 0.01;
    span.longitudeDelta = 0.01;
    
    region.center = cordinate;
    region.span = span;
    
    [self.objMapView setRegion:region animated:true];
    
    
    CLLocationCoordinate2D location;
    location.latitude = leti;
    location.longitude = longi;
    
    Annotation *myAnnotation = [Annotation alloc];
    myAnnotation.coordinate = location;
    myAnnotation.title = @"King";
    myAnnotation.subTitle = @"I Am here";
    
    [self.objMapView addAnnotation:myAnnotation];
    
    [_objimgview sd_setImageWithURL:_imgURL placeholderImage:[UIImage imageNamed:@"loding.lodijpg"]];
    
    _objName.text = _passName;
    _objOrganizeName.text = _passOrganize;
    _objLocation.text = _passLocation;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnBack:(id)sender {
    
    [self dismissViewControllerAnimated:true completion:nil];

}
@end
