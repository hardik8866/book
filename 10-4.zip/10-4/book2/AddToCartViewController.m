//
//  AddToCartViewController.m
//  book2
//
//  Created by Royal on 26/2/18.
//  Copyright © 2018 Royal. All rights reserved.
//

#import "AddToCartViewController.h"
#import "cartListViewController.h"

@interface AddToCartViewController () <WebServicesDelegate>
{
    int totalPrice;
}
@property (weak, nonatomic) IBOutlet UIButton *btnAddTocart;
@property (weak, nonatomic) IBOutlet UIImageView *objImageView;
@property (weak, nonatomic) IBOutlet UITextField *txtQuantity;
@property (weak, nonatomic) IBOutlet UILabel *lblPrice;
@property (weak, nonatomic) IBOutlet UILabel *lblTotalPrice;


@end

@implementation AddToCartViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [_objImageView sd_setImageWithURL:_imageUrl];
    _lblPrice.text = _price;
    _txtQuantity.delegate = self;
    // Do any additional setup after loading the view.
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)AddToCartAndShowCartController:(id)sender {
    
    WebServices *objweb;
    objweb = [WebServices sharedInstance];
    objweb.delegate = self;
    
//isbn_no:0785120122
//book_qty:2
//price:1000
//user_id:33
    
    NSDictionary *dic = @{
                          @"isbn_no":_isbnNumber,
                          @"book_qty":_txtQuantity.text,
                          @"price":_lblPrice.text,
                              @"user_id": UserId
                          };
    [objweb callApiWithParameters:dic apiName:@"http://someshwarmahadev.com/royaltech/index.php/api/add_to_cart" type:POST_REQUEST loader:NO view:self];
    
//    cartListViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"cartListViewController"];
//    vc.isbn = _isbnNumber;
//    vc.Name = _bookName;
//    vc.quantity = _txtQuantity.text;
//    vc.totalPrice = _lblTotalPrice.text;
//    vc.imageUrl = _imageUrl;
//    [self presentViewController:vc animated:true completion:nil];
}

- (IBAction)BackAction:(id)sender {
    [self dismissViewControllerAnimated:true completion:nil];
}
- (void)textFieldDidBeginEditing:(UITextField *)textField{
    [_txtQuantity becomeFirstResponder];
}           // became first responder
- (BOOL)textFieldShouldEndEditing:(UITextField *)textField{
    int price,quentity;
    price = [_lblPrice.text integerValue];
    quentity = [textField.text integerValue];
    totalPrice = price * quentity;
    _lblTotalPrice.text = [NSString stringWithFormat:@"%i", totalPrice];
    return YES;
}
 - (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [_txtQuantity resignFirstResponder];
    return YES;
}
-(void)response:(NSDictionary *)responseDict apiName:(NSString *)apiName ifAnyError:(NSError *)error{
     int status = [responseDict valueForKey:@"status"];
    if (status == 19){
        cartListViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"cartListViewController"];
        [self presentViewController:vc animated:true completion:nil];
    }else{
        //Show Ale
    }
}
// called when 'return' key pressed. return NO to ignore.

@end
