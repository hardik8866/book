//
//  bookCategoryViewController.h
//  book2
//
//  Created by Royal on 15/2/18.
//  Copyright © 2018 Royal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface bookCategoryViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITableView *Tbltableview;

@end
