//
//  HomeViewController.m
//  book2
//
//  Created by Royal on 13/2/18.
//  Copyright © 2018 Royal. All rights reserved.
//

#import "HomeViewController.h"
#import "bookdetailView.h"
#import "bookCategoryViewController.h"
#import <SDWebImage/UIImageView+WebCache.h>

@interface HomeViewController () <UICollectionViewDelegate, UICollectionViewDataSource,WebServicesDelegate,UICollectionViewDelegateFlowLayout>
{
    NSArray *BookImageArray;
    NSArray *Catname;
    NSArray *CatImageurl;
    NSArray *BookId;
}

@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    WebServices *objweb;
    objweb = [WebServices sharedInstance];
    objweb.delegate = self;
    [objweb callApiWithParameters:nil apiName:@"http://someshwarmahadev.com/royaltech/index.php/api/category_list" type:POST_REQUEST loader:NO view:self];
    
    
    
    //BookImageArray = @[@"Adventure.png",@"Anthology.jpg",@"Biographies.jpg",@"Adventure.png",@"Anthology.jpg",@"Biographies.jpg"];
    // Do any additional setup after loading the view.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}





- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return CatImageurl.count;
}

// The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:
- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
//    UILabel *testLabel = [cell viewWithTag:1];
//    testLabel.text = @"1";
    UIImageView *img = [cell viewWithTag:1];
    //img.image = [UIImage imageNamed:BookImageArray[indexPath.row]];
    [img sd_setImageWithURL:[CatImageurl objectAtIndex:indexPath.row] placeholderImage:[UIImage imageNamed:@"loding.jpg"]];
    
    UILabel *objname = [cell viewWithTag:2];
    objname.text = Catname[indexPath.row];
    
    return cell;
}
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    bookCategoryViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"bookCategoryViewController"];
    vc.Category = Catname[indexPath.row];
    [self presentViewController:vc animated:YES completion:nil];
}

-(void)response:(NSDictionary *)responseDict apiName:(NSString *)apiName ifAnyError:(NSError *)error{
    printf("%@", responseDict);
    NSError *jsonError;
    NSDictionary *dic = responseDict;
    if (dic==nil) {
        NSLog(@"nil");
    }
    else
    {
        Catname = [dic valueForKeyPath:@"message.name"];
        CatImageurl = [dic valueForKeyPath:@"message.image"];
        BookId = [dic valueForKeyPath:@"message.id"];
        [self.CatCollectionView reloadData];
    }
}
- (IBAction)searchAction:(id)sender {
    UIViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"SearchViewController"];
    [self.navigationController pushViewController:vc animated:true];
}
- (IBAction)logoutAction:(id)sender {
    [self.navigationController popViewControllerAnimated:true];
}


-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    CGFloat width = collectionView.bounds.size.width/3;
    CGFloat hight = width+20;
    
    return CGSizeMake(width, hight);
}




@end
