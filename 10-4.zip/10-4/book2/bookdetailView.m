
//
//  bookdetailView.m
//  book2
//
//  Created by Royal on 13/2/18.
//  Copyright © 2018 Royal. All rights reserved.
//

#import "bookdetailView.h"
#import "AddToCartViewController.h"
#import "ReadPdfViewController.h"
@interface bookdetailView ()

@end

@implementation bookdetailView

- (void)viewDidLoad {
    [super viewDidLoad];

    // bookdetail

    
   // _objimgview.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:_passimgURL]]];;
   
    [_objimgview sd_setImageWithURL:_passimgURL placeholderImage:[UIImage imageNamed:@"loding.jpg"]];

    
    _objisbn.text = _passisbn;
    _objName.text = _passname;
    _objPrice.text = _passprice;
    _objAuthor.text = _passauthor;
    _objinformationTextview.text = _passinformation;


}
- (IBAction)AddToCart:(id)sender {
    AddToCartViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"AddToCartViewController"];
    vc.imageUrl = _passimgURL;
    vc.price = _passprice;
    vc.isbnNumber = _passisbn;
    vc.bookName = _passname;
    [self presentViewController:vc animated:true completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)BackAction:(id)sender {
    [self dismissViewControllerAnimated:true completion:nil];
}
- (IBAction)BtnBookRead:(id)sender {
    ReadPdfViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"ReadPdfViewController"];
  // vc.Pdfurl = 
    [self presentViewController:vc animated:YES completion:nil];
}


@end
