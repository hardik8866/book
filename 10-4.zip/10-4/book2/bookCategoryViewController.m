//
//  bookCategoryViewController.m
//  book2
//
//  Created by Royal on 15/2/18.
//  Copyright © 2018 Royal. All rights reserved.
//

#import "bookCategoryViewController.h"
#import "bookdetailView.h"
#import "SearchViewController.h"
#define GET_REQUEST                             @"GET"
@interface bookCategoryViewController ()<WebServicesDelegate,UITableViewDataSource,UITableViewDelegate>
{
    NSArray *name;
    NSArray *isbn;
    NSArray *price;
    NSArray *bookauthor;
    NSArray *bookimageurl;
    NSArray *bookCategory;
    NSArray *information;
    NSDictionary *dic;
}
@property (weak, nonatomic) IBOutlet UIButton *btnBack;

// Do any additional setup after loading the view.
@end

@implementation bookCategoryViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    WebServices *objweb;
    objweb = [WebServices sharedInstance];
    objweb.delegate = self;
    
    [objweb callApiWithParameters:nil apiName:@"http://someshwarmahadev.com/royaltech/index.php/api/book_list/" type:GET_REQUEST loader:NO view:self];

    self.Tbltableview.delegate = self;
    self.Tbltableview.dataSource = self;

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)BackAcion:(id)sender {
    [self dismissViewControllerAnimated:true completion:nil];
}
- (IBAction)tempAction:(id)sender {
    UIViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"bookdetailView"];
    [self presentViewController:vc animated:true completion:nil];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return name.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    UIImageView *imageView = [cell viewWithTag:99];
    UILabel *lbltag2 = [cell viewWithTag:11];
    UILabel *lbltag3 = [cell viewWithTag:12];
    UILabel *lbltag4 = [cell viewWithTag:13];
    UILabel *lbltag5 = [cell viewWithTag:14];
    [imageView sd_setImageWithURL:[bookimageurl objectAtIndex:indexPath.row] placeholderImage:[UIImage imageNamed:@"loding.jpg"]];
    
    lbltag2.text = [isbn objectAtIndex:indexPath.row];
    lbltag3.text = [name objectAtIndex:indexPath.row];
    lbltag4.text = [price objectAtIndex:indexPath.row];
    lbltag5.text =[bookauthor objectAtIndex:indexPath.row];
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
 
    
    UIStoryboard *sb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    bookdetailView *vc = [sb instantiateViewControllerWithIdentifier:@"bookdetailView"];
    
    vc.passimgURL = bookimageurl[indexPath.row];
    vc.passisbn = isbn[indexPath.row];
    vc.passname = name[indexPath.row];
    vc.passprice = price[indexPath.row];
    vc.passauthor = bookauthor[indexPath.row];
    vc.passinformation = information[indexPath.row];
    
    
    [self presentViewController:vc animated:YES completion:NULL];
    
    
    
//    UIViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"bookdetailView"];
//    [self.navigationController presentViewController:vc animated:true completion:nil];
}

//MARK: - Search Action
- (IBAction)searchAction:(id)sender {
    
    UIStoryboard *sb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    SearchViewController *vc = [sb instantiateViewControllerWithIdentifier:@"SearchViewController"];
    vc.tempDict = dic;
    [self presentViewController:vc animated:true completion:nil];
//    [self.navigationController presentViewController:vc animated:true completion:nil];
}

-(void)response:(NSDictionary *)responseDict apiName:(NSString *)apiName ifAnyError:(NSError *)error{
    printf("%@", responseDict);
    NSError *jsonError;
//    NSDictionary *dic;
    dic = [NSJSONSerialization JSONObjectWithData:responseDict
                                          options:NSJSONReadingMutableContainers
                                            error:&jsonError];
    name = [dic valueForKeyPath:@"message.name"];
    isbn = [dic valueForKeyPath:@"message.isbn"];
    price = [dic valueForKeyPath:@"message.price"];
    bookauthor = [dic valueForKeyPath:@"message.book_author"];
    bookimageurl = [dic valueForKeyPath:@"message.book_image"];
    bookCategory = [dic valueForKeyPath:@"message.category"];
    information = [dic valueForKeyPath:@"message.information"];
    
    [self.Tbltableview reloadData];
    //    printf("%@",dic);
    
//    message = [dic valueForKey:@"message"];
//
//    name = [dic valueForKeyPath:@"message.name"];
//    imageurl = [dic valueForKeyPath:@"message.image"];
//    location = [dic valueForKeyPath:@"message.location"];
//    organaizer_name = [dic valueForKeyPath:@"message.orgranazer_name"];
//    [self.TblEventView reloadData];
    
}

@end
