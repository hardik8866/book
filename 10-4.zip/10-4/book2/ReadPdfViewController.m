//
//  ReadPdfViewController.m
//  book2
//
//  Created by MyClassCampus on 4/10/18.
//  Copyright © 2018 Royal. All rights reserved.
//

#import "ReadPdfViewController.h"

@interface ReadPdfViewController ()

@end

@implementation ReadPdfViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"%@", _Pdfurl);
    // Do any additional setup after loading the view.
    NSURL *targetURL = [NSURL URLWithString:@"https://www.example.com/document.pdf"];
    NSURLRequest *request = [NSURLRequest requestWithURL:targetURL];
    [self.webview loadRequest:request];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
