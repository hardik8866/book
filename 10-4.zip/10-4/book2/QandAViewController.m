//
//  QandAViewController.m
//  book2
//
//  Created by Royal on 26/2/18.
//  Copyright © 2018 Royal. All rights reserved.
//

#import "QandAViewController.h"

@interface QandAViewController () <UITableViewDataSource,UITableViewDelegate,WebServicesDelegate>
{
    NSArray *message;
    NSArray *qid;
}
@end

@implementation QandAViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    WebServices *objweb;
    objweb = [WebServices sharedInstance];
    objweb.delegate = self;
    [objweb callApiWithParameters:nil apiName:@"http://someshwarmahadev.com/royaltech/index.php/api/list_question_answer" type:GET_REQUEST loader:NO view:self];

    // Do any additional setup after loading the view.
}
-(void)response:(NSDictionary *)responseDict apiName:(NSString *)apiName ifAnyError:(NSError *)error{
    printf("%@", responseDict);
    NSError *jsonError;
    NSDictionary *dic;
    dic = [NSJSONSerialization JSONObjectWithData:responseDict
                                          options:NSJSONReadingMutableContainers
                                            error:&jsonError];
    message = [dic valueForKey:@"message"];
    qid = [dic valueForKeyPath:@"message.question"];
    printf("%s", qid);
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    return cell;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

@end
