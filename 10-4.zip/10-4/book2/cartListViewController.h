//
//  cartListViewController.h
//  book2
//
//  Created by Royal on 27/2/18.
//  Copyright © 2018 Royal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface cartListViewController : UIViewController

@property (nonatomic, weak) NSString *isbn;
@property (nonatomic, weak) NSString *Name;
@property (nonatomic, weak) NSString *quantity;
@property (nonatomic, weak) NSString *totalPrice;
@property (nonatomic, weak) NSURL * imageUrl;
@property (weak, nonatomic) IBOutlet UILabel *lblTotalAmountOfUserBook;


@end
